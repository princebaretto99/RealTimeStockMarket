var express = require('express');
var router = express.Router();
var multer = require('multer');
const path = require('path');
var fs = require('fs');

// var storage =   multer.diskStorage({  
//   destination: function (req, file, callback) {  
//     callback(null, '../uploads');  
//   },  
//   filename: function (req, file, callback) {  
//     callback(null, file.originalname);  
//   }  
// });  

// var upload = multer({ storage : storage});
var upload = multer({ dest: path.join(__dirname, '../uploads')})

/* GET home page. */
router.get('/', function(req, res, next) {
  if (!req.session.visits) {
    req.session.visits = 1;
  } else {
    req.session.visits += 1;
  }

  const username = req.user ? req.user.username : '';

  res.render('index', {
    title: 'Express',
    visits: req.session.visits,
    loggedIn: req.user,
    username,
  });
});

router.post('/',upload.single("singleInputFileName") , (req,res) =>{
  // upload(req,res,function(err) {  
  //   if(err) {  
  //     console.error(err) 
  //     return res.end("Error uploading file.");  
  //   }  
  //   console.dir(req.files)
  //   res.end("File is uploaded successfully!");  
  // }); 
  console.log(req.file)
  myPath = path.join(__dirname, '../uploads/'+ req.file.filename)
  newPath = path.join(__dirname, '../uploads/'+ req.file.originalname)
  
  fs.rename(myPath, newPath, function(err) {
      if ( err ) console.log('ERROR: ' + err);
  });
  res.end("File is uploaded successfully!");
});

module.exports = router;
