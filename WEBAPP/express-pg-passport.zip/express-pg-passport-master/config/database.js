module.exports = {
  host: "localhost",
  user: "postgres",
  database: "nodeJS",
  password: "Prince@99",
  port: "5432",
}