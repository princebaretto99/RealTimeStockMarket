// Postgres Error codes
module.exports = {
  unique_violation: 23505
};
